You need to download the Latest Bedrock User Guide PDF file from  https://docs.aws.amazon.com/pdfs/bedrock/latest/userguide/bedrock-ug.pdf and put it in this folder.

Make sure the file size of northwind.db is around 12MB ore more. it is recommended to download the file manually from the above link and upload to this working directory. Commands like wget may cause incorrect download file size.
