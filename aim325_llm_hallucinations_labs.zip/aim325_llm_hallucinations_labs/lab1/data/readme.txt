the lab notebook will download the bedrock user guide from here 
https://docs.aws.amazon.com/pdfs/bedrock/latest/userguide/bedrock-ug.pdf 
